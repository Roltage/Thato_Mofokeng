# AFCON Football NoSQL Database

**Course:** DDB361 — Assignment 2  
**Database:** MongoDB  
**Programming Language:** Python  
**Author / Team Member:** Thato Mofokeng  
**Team Members:** Thabo Sibeko, Thato Mofokeng, Nathi Juta, Thabile Ditshego

## Project Overview

The AFCON Football NoSQL Database is a project focused on storing and retrieving statistics related to the 2023 Africa Cup of Nations (AFCON) tournament using MongoDB. It covers player profiles, match information, basic data queries, a command-line interface, and database backup and restoration.

The database was designed to organise football information in a document-oriented NoSQL structure and provide a simple way to look up player statistics and match details.

## Database Design

The documented implementation uses the `AFCON_DB` MongoDB database with two collections:

- **`players`** — player information such as name, age, nationality, club, goals, and assists.
- **`matches`** — match information such as match ID, teams, score, date, and location.

The assignment also identifies a `teams` collection as part of the proposed schema, with fields such as country, players, coach, and total wins. The documented Python setup creates the `players` and `matches` collections.

## Features

- Create or access the `AFCON_DB` database and its collections.
- Retrieve all player records.
- Search for a player by name.
- Find players with more than two goals.
- Retrieve match records and results.
- Use a menu-driven command-line interface.
- Back up and restore the MongoDB database using MongoDB Database Tools.
- Support local MongoDB hosting, with MongoDB Atlas described as a cloud-hosting option.

## Technologies Used

- **MongoDB** — document-oriented NoSQL database
- **Python** — application and database interaction
- **PyMongo** — Python driver for MongoDB
- **MongoDB Database Tools** — database backup and restoration
- **Command-line interface (CLI)** — user interaction

## Example Queries

The project documentation includes examples such as:

### Retrieve all players

```python
for player in players.find():
    print(player)
```

### Search for a player by name

```python
player = players.find_one({"name": "Victor Osimhen"})
print(player)
```

### Find players with more than two goals

```python
for player in players.find({"goals": {"$gt": 2}}):
    print(player)
```

### Retrieve match details

```python
for match in matches.find():
    print(match)
```

## Command-Line Menu

The documented CLI provides options to:

1. View all players
2. Search for a player by name
3. View match results
4. Exit the application

## Getting Started

### Requirements

- Python 3
- MongoDB running locally, or a configured MongoDB Atlas cluster
- The Python package `pymongo`
- MongoDB Database Tools if you want to run the backup and restore commands

### Install PyMongo

```bash
python -m pip install pymongo
```

### Configure the Database Connection

The documented local connection uses:

```python
from pymongo import MongoClient

client = MongoClient("mongodb://localhost:27017/")
db = client["AFCON_DB"]
players = db["players"]
matches = db["matches"]
```

Make sure MongoDB is running before launching the Python application. If you use MongoDB Atlas, replace the local connection string with your Atlas connection string and keep credentials private.

### Run the Application

The assignment document describes the database setup and CLI examples, but does not specify the Python script's filename. Once you have added the relevant `.py` file to your repository, run it with:

```bash
python <your-script-name>.py
```

Replace `<your-script-name>.py` with the actual filename.

## Backup and Restore

The project documentation includes the following commands for backing up and restoring the database.

### Create a backup

```bash
mongodump --db AFCON_DB --out backup/
```

### Restore the database

```bash
mongorestore --db AFCON_DB backup/AFCON_DB
```

A backup folder or compressed backup archive should be included in the repository only if it is available and appropriate to share. Do not upload database credentials or private connection strings.

## Project Structure

The exact repository structure depends on the files you upload. A possible structure is:

```text
AFCON-Football-NoSQL-Database/
├── README.md
├── <python-script>.py
└── backup/                 # Optional: include if a backup is provided
```

## Learning Outcomes

This project demonstrates experience with:

- NoSQL database design and document collections
- Connecting Python applications to MongoDB with PyMongo
- Querying documents using MongoDB filters
- Building a basic command-line database interface
- Understanding database hosting options
- Backing up and restoring a MongoDB database

## Challenges and Future Improvements

The project reflection identifies data collection and manual data entry as challenges. Suggested future improvements include building a web-based user interface and automating data population.

Other possible extensions include adding indexes for frequently queried fields, expanding team-related data, and adding automated tests.

## Project Documentation

The accompanying assignment document is titled **AFCON Football NoSQL Database** and was prepared for DDB361 Assignment 2.

## License

No license is specified in the assignment documentation. Add a license if you intend to allow others to reuse or distribute this project.
