#  The Lynx Project — Personal AI Assistant

**The Lynx Project** is a Python-based personal AI assistant inspired by intelligent virtual assistants like JARVIS from Marvel's *Iron Man*. The goal of the project is to create a voice-controlled assistant that can listen to commands, interact with an AI model, and eventually perform useful tasks on a computer and connected devices.

The project is being developed in Python using Visual Studio Code, with a focus on voice recognition, text-to-speech, and AI-powered conversations.

##  Project Goals

The main goal is to develop a personal AI assistant capable of:

- Recognizing voice commands and responding to spoken requests.
- Detecting its wake word before processing commands.
- Generating intelligent responses using the OpenAI API.
- Speaking responses aloud through text-to-speech.
- Expanding into computer automation and remote device control.

##  Technologies Used

| Technology | Purpose |
|---|---|
| Python | Core programming language |
| Visual Studio Code | Development environment |
| OpenAI API | AI-powered responses |
| `speech_recognition` | Voice input and speech recognition |
| `pyttsx3` | Offline text-to-speech |
| Windows SAPI5 | Speech synthesis engine |
| Environment variables | Secure API key configuration |

##  Features

### Implemented

- **Voice recognition:** Uses the `speech_recognition` library to process microphone input.
- **Wake-word detection:** Recognizes variations of the assistant's name, including `Lynx`, `Linx`, `Links`, `Lings`, and `Lanks`.
- **AI integration:** Connects to the OpenAI API to generate conversational responses.
- **Voice responses:** Uses `pyttsx3` with the Windows SAPI5 engine to speak responses aloud.
- **Speech configuration:** Configured speech output with a speaking rate of approximately 180 words per minute.
- **Iterative development:** Built through incremental versions, with improvements and bug fixes as development progresses.

### Planned Features

- [ ] Improve wake-word accuracy and speech recognition.
- [ ] Add more natural conversational interactions.
- [ ] Execute useful computer commands through voice input.
- [ ] Open applications and automate repetitive tasks.
- [ ] Integrate phone control so Lynx can interact with a connected mobile device.
- [ ] Add additional personal assistant features as development continues.

##  Getting Started

### Prerequisites

Before running the project, ensure you have:

- Python installed on your computer.
- Visual Studio Code or another Python-compatible editor.
- A working microphone and speakers.
- An OpenAI API key.
- An internet connection for AI API requests.

### 1. Clone the repository

```bash
git clone YOUR_REPOSITORY_URL
cd PROJECT-JARVIS-LYNX
```

Replace `YOUR_REPOSITORY_URL` with your actual GitHub repository URL. Adjust the folder name if your repository uses a different name.

### 2. Create a virtual environment

```bash
python -m venv venv
```

Activate it on Windows:

```powershell
.\venv\Scripts\Activate.ps1
```

Alternatively, use Command Prompt:

```cmd
venv\Scripts\activate.bat
```

### 3. Install dependencies

```bash
pip install openai SpeechRecognition pyttsx3
```

Depending on your microphone configuration and the version of the project, you may also need the appropriate audio input dependency, such as `PyAudio`.

### 4. Configure your API key

Set your OpenAI API key as an environment variable rather than writing it directly into your Python source code.

For the current PowerShell session:

```powershell
$env:OPENAI_API_KEY="your_api_key_here"
```

Replace the placeholder with your actual API key. Never commit API keys or other secrets to GitHub.

### 5. Run the assistant

Run the main Python script from the project directory. For example, if the entry-point file is named `main.py`:

```bash
python main.py
```

Use the actual entry-point filename in your repository.

##  Project Structure

The structure below is a suggested organization for the project as it grows. Adapt it to match the files currently in your repository.

```text
PROJECT-JARVIS-LYNX/
├── main.py
├── requirements.txt
├── README.md
├── .gitignore
├── src/
│   ├── speech_recognition.py
│   ├── text_to_speech.py
│   └── ai_assistant.py
└── venv/
```

**Note:** Do not commit your virtual environment folder. Add `venv/`, `.env`, and other local or sensitive files to `.gitignore`.

##  Security

- Store API credentials in environment variables.
- Never upload API keys, passwords, or private configuration files to a public repository.
- Review any command-execution functionality carefully before allowing the assistant to run system commands.
- Remember that AI API requests may incur usage costs.

##  Development Roadmap

**Phase 1 — Core Assistant**
- Set up Python and the development environment.
- Implement voice recognition and spoken responses.
- Integrate the OpenAI API.
- Develop wake-word detection.

**Phase 2 — Smarter Interactions**
- Improve recognition accuracy.
- Refine conversation handling.
- Add command interpretation and error handling.

**Phase 3 — Automation**
- Introduce controlled computer automation.
- Add application launching and useful system commands.
- Expand the assistant's capabilities through modular Python components.

**Phase 4 — Remote Device Control**
- Investigate secure communication between Lynx and a mobile phone.
- Implement selected remote-control features.
- Add appropriate authentication and safety checks.

##  Project Vision

The long-term vision is to turn Lynx into a personalized AI assistant that combines voice interaction, intelligent responses, computer automation, and remote device functionality.

This project is also an opportunity to strengthen practical skills in Python development, API integration, speech processing, software architecture, and AI application development.

## Author

**Thato Mofokeng**

Aspiring software developer with an interest in Python, artificial intelligence, automation, and building practical software solutions.

---

*The Lynx Project is an independent learning and development project. Features and capabilities are being introduced incrementally as development continues.*
