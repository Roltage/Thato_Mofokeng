import speech_recognition as sr
import pyttsx3
import time
from difflib import SequenceMatcher
from openai import OpenAI
from dotenv import load_dotenv
import os

# ===========================
# LOAD API KEY
# ===========================
load_dotenv()
client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

# ===========================
# TEXT-TO-SPEECH
# ===========================
engine = pyttsx3.init(driverName='sapi5')
engine.setProperty("rate", 180)

def speak(text):
    print(f"Lynx: {text}")
    engine.say(text)
    engine.runAndWait()


# ===========================
# FUZZY WAKE WORD DETECTION
# ===========================
def is_wake_word(text):
    if not text:
        return False

    words = text.lower().split()
    wake_words = ["lynx", "linx", "links", "lings", "lanks"]

    for w in words:
        for wake in wake_words:
            ratio = SequenceMatcher(None, w, wake).ratio()
            if ratio > 0.65:      # 65% similarity threshold
                return True

    return False

# ===========================
# LISTENING FUNCTION
# ===========================
recognizer = sr.Recognizer()
mic = sr.Microphone()

def listen():
    with mic as source:
        recognizer.adjust_for_ambient_noise(source, duration=0.3)
        print("Listening...")
        audio = recognizer.listen(source)

    try:
        text = recognizer.recognize_google(audio)
        print(f"Heard: {text}")
        return text
    except sr.UnknownValueError:
        return ""
    except Exception as e:
        print(f"Error: {e}")
        return ""

# ===========================
# OPENAI GENERATION
# ===========================
def ask_lynx(prompt):
    completion = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {"role": "system", "content": "You are Lynx, a smart AI assistant."},
            {"role": "user", "content": prompt}
        ]
    )

    return completion.choices[0].message.content



# ===========================
# MAIN LOOP
# ===========================
print("Lynx 0.2 is running... Say 'Lynx' to activate.")

lynx_active = False

while True:
    text = listen()

    if not lynx_active:
        if is_wake_word(text):
            speak("Yes? How can I help?")
            lynx_active = True
        continue


    if "stop listening" in text.lower():
        speak("Okay, call me if you need me.")
        lynx_active = False
        continue

    if text:
        response = ask_lynx(text)
        speak(response)

