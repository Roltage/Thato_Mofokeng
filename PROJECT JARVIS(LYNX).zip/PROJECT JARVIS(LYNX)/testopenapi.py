from openai import OpenAI
from dotenv import load_dotenv
import os

load_dotenv()

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

try:
    response = client.responses.create(
        model="gpt-4.1-mini",
        input="Hello Lynx!"
    )
    print("✅ API is working!")
    print("AI says:", response.output_text)

except Exception as e:
    print("❌ Error:", e)
