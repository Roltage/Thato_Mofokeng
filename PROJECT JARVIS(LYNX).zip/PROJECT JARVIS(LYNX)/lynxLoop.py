from voice import listen, speak
from openai import OpenAI
from dotenv import load_dotenv
import os

load_dotenv()

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

print("\n🔊 Lynx is active. Say something...\n")

while True:
    text = listen()

    if text is None:
        continue

    # Stop phrase
    if text.lower() in ["stop", "sleep", "shutdown lynx"]:
        speak("Okay, shutting down.")
        break

    # Send text to AI model
    response = client.responses.create(
        model="gpt-4.1-mini",
        input=text
    )

    reply = response.output_text
    print("Lynx:", reply)
    speak(reply)
