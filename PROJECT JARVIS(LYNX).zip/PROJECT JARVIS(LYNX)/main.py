from fastapi import FastAPI
from pydantic import BaseModel
from voice import speak
from openai import OpenAI
from dotenv import load_dotenv
import os

load_dotenv()

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
app = FastAPI()

class UserInput(BaseModel):
    text: str

@app.post("/lynx")
def lynx_endpoint(data: UserInput):
    user_text = data.text

    # Send text to the OpenAI model
    response = client.responses.create(
        model="gpt-4.1-mini",
        input=user_text
    )

    ai_reply = response.output_text
    speak(ai_reply)

    return {"response": ai_reply}
