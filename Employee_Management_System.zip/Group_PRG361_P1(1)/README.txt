# Employee Management System – Java

## Project Overview

The Employee Management System is a group project developed for **Programming 361 at Belgium Campus iTversity**. The project combines a web-based employee authentication system with a desktop application for managing employee information and administrative operations.

The project was divided into two milestones:

- **Milestone 1 – Web Application:** An employee login and registration system built using JSP, Java Servlets, and PostgreSQL.
- **Milestone 2 – Desktop Application:** A desktop employee management system developed using Java Swing, NetBeans GUI Builder, and JavaDB.

The system demonstrates the application of object-oriented programming, database integration, GUI development, and CRUD operations in Java.

## Project Objectives

- Apply core Java programming and object-oriented programming (OOP) principles.
- Develop employee registration and authentication functionality.
- Integrate Java applications with relational databases.
- Implement CRUD operations for employee and administrative records.
- Apply exception handling, collections, encapsulation, inheritance, polymorphism, and abstraction.
- Develop interactive graphical user interfaces with event handling.

## Technologies Used

| Component | Technologies |
|---|---|
| Programming Language | Java |
| Web Frontend | JavaServer Pages (JSP) |
| Web Backend | Java Servlets |
| Web Database | PostgreSQL |
| Application Server | Apache Tomcat / GlassFish |
| Desktop GUI | Java Swing |
| GUI Builder | NetBeans IDE GUI Builder |
| Desktop Database | JavaDB (Embedded) |
| Development Environment | NetBeans IDE |

## Features

### 1. Web Login and Registration System

- Home page with login and registration navigation.
- Employee registration using employee and contact information.
- Employee authentication using employee ID and password.
- Dashboard with logout functionality.
- Server-side validation and error handling.
- Prevention of duplicate employee IDs and email addresses.

### 2. Desktop Employee Management System

- Main dashboard with navigation between management modules.
- Employee management: create, view, update, and delete employee records.
- Department management and employee assignment.
- Role management.
- Payroll management and salary processing.
- Payslip generation.
- Database integration using JavaDB.
- GUI event handling and interaction between interface components and backend functionality.

## My Contribution

**Role: Desktop Back-end Developer**

My primary responsibility was implementing the backend functionality for the desktop Employee Management System using Java and NetBeans.

My responsibilities included:

- Implementing Java backend logic for the desktop application.
- Applying object-oriented programming principles to the application design.
- Developing business logic to support the desktop application's functionality.
- Integrating the Java application with JavaDB.
- Supporting database operations and CRUD functionality.
- Structuring backend components to work with the desktop user interface.

This work provided practical experience in Java application development, backend logic implementation, database integration, and object-oriented software design.

## Project Structure

The project consists of two main components.

### Web Application

- JSP pages for the user interface.
- Servlets for processing registration and login requests.
- PostgreSQL database for employee and login information.
- Server-side validation and authentication logic.

### Desktop Application

- Swing forms for the graphical user interface.
- Model classes representing application entities.
- Data Access Object (DAO) components for database access.
- JavaDB tables for employees, departments, roles, and payroll.
- Backend business logic for application operations.

*Note: The exact folder and package names depend on the submitted project structure.*

## Database Design

The project uses two databases for separate application components.

**PostgreSQL – Web Application**
- Employee information.
- Login and authentication information.

**JavaDB – Desktop Application**
- Employee records.
- Department records.
- Role information.
- Payroll records.

## Learning Outcomes

Through this project, I gained practical experience in:

- Java programming and object-oriented design.
- Desktop application backend development.
- Relational database integration.
- CRUD operations and data management.
- Separation of application responsibilities.
- Collaborating on a multi-component software development project.

## Project Information

- **Institution:** Belgium Campus iTversity
- **Module:** Programming 361
- **Project Type:** Group Project
- **Development Period:** 2026
- **Primary Language:** Java

## Team Contributions

| Team Member | Responsibility |
|---|---|
| Thabo Sibeko | Web frontend development using JSP |
| Thato Mofokeng | Desktop backend development using Java |
| Kgotho Molala | Desktop frontend development using Java Swing Database Developer | PostgreSQL database design and implementation |

## Video Demonstrations

The following video demonstrations showcase the Employee Management System and provide an overview of the work completed by each team member.

Each team member explains their respective responsibilities, implementation approach, and contribution to the project.

- **Web Frontend Demonstration:** Overview of the employee login, registration, and dashboard functionality.
- **Desktop Backend Demonstration:** Explanation of the Java backend logic, object-oriented design, and JavaDB integration.
- **Desktop Frontend Demonstration:** Walkthrough of the Java Swing graphical user interface and its interaction with the application functionality.
- **Database Demonstration:** Overview of the database design, tables, and data management functionality.

### Watch the Demonstrations

The demonstration videos are available here:

- [View Video Demonstrations](PASTE_YOUR_VIDEO_LINK_HERE)



## Notes

This repository documents an academic software development project completed as part of the Programming 361 module.

The project demonstrates the integration of web technologies, Java desktop development, and relational databases in an employee management application.

