/*CREATE TABLE EndUsers(
 id SERIAL PRIMARY KEY,
 first_name VARCHAR(100) NOT NULL,
 surname VARCHAR(100) NOT NULL,
 email VARCHAR(255) NOT NULL UNIQUE,
 phone VARCHAR(20),
 department VARCHAR(100),
 role VARCHAR(100),
 office_location VARCHAR(150),
 password_hash VARCHAR(255) NOT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);*/

/*INSERT INTO EndUsers (first_name, surname, email, phone, department, role, office_location, password_hash) 
VALUES ('Thandi', 'Nkosi', 'thandi@mzansi.co.za', '+27 82 123 4567', 
        'Innovation Dept', 'Senior Product Lead', 'Cape Town', 
        '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92');*/

SELECT * FROM EndUsers

