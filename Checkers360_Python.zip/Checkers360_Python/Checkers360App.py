# Checkers360 Shopping Cart Application
#Thato Mofokeng 601447

# Here we are initializing the shopping cart
import sys

class Checkers360:
    def __init__(self):
        self.stock = {"Laptop": {"price": 12000.00, "quantity": 6},
                      "Headphones": {"price": 600.00, "quantity": 2}}
        self.cart = {}#Format: {"Item": (price, quantity)}

    def add_to_cart(self):
        print("\nAvailable Items:")
        for item, details in self.stock.items():
            print(f"{item} - R{details['price']} (Stock: {details['quantity']})")
        
        choice = input("Enter item name to add to cart: ").strip().title()
        if choice in self.stock:
            try:
                quantity = int(input(f"Enter quantity (Max {self.stock[choice]['quantity']}): "))
                if 0 < quantity <= self.stock[choice]['quantity']:
                    if choice in self.cart:
                        self.cart[choice] = (self.stock[choice]['price'], self.cart[choice][1] + quantity)
                    else:
                        self.cart[choice] = (self.stock[choice]['price'], quantity)
                    self.stock[choice]['quantity'] -= quantity
                    print(f"✅ {quantity} {choice}(s) added to cart!")
                else:
                    print("⚠️ Invalid quantity! Please enter a valid number.")
            except ValueError:
                print("⚠️ Please enter a valid number!")
        else:
            print("❌ Item not available! Try again.")

    def view_cart(self):
        if not self.cart:
            print("\n🛒 Your cart is empty!")
        else:
            print("\n🛍️ Your Cart:")
            for item, (price, quantity) in self.cart.items():
                print(f"{item}: {quantity} (Total: R{price * quantity:.2f})")

    def remove_from_cart(self):
        if not self.cart:
            print("\n🛒 Your cart is already empty!")
            return
        
        choice = input("Enter item name to remove from cart: ").strip().title()
        if choice in self.cart:
            try:
                quantity = int(input(f"Enter quantity to remove (Max {self.cart[choice][1]}): "))
                if 0 < quantity <= self.cart[choice][1]:
                    new_quantity = self.cart[choice][1] - quantity
                    self.stock[choice]['quantity'] += quantity
                    if new_quantity == 0:
                        del self.cart[choice]
                    else:
                        self.cart[choice] = (self.cart[choice][0], new_quantity)
                    print(f"🗑️ {quantity} {choice}(s) removed from cart!")
                else:
                    print("⚠️ Invalid quantity! Try again.")
            except ValueError:
                print("⚠️ Please enter a valid number!")
        else:
            print("❌ Item not found in cart!")

    def calculate_total(self):
        total = sum(price * quantity for price, quantity in self.cart.values())
        print(f"\n💰 Total Amount: R{total:.2f}")

    def run(self):
        while True:
            print("\n📌 Checkers360 Menu:")
            print("1️⃣  Add to Cart")
            print("2️⃣  View Cart")
            print("3️⃣  Remove from Cart")
            print("4️⃣  Calculate Total")
            print("5️⃣  Exit")
            choice = input("Enter your choice: ")
            
            if choice == "1":
                self.add_to_cart()
            elif choice == "2":
                self.view_cart()
            elif choice == "3":
                self.remove_from_cart()
            elif choice == "4":
                self.calculate_total()
            elif choice == "5":
                print("👋 Exiting Checkers360. Thanks for shopping with us!")
                sys.exit()
            else:
                print("❌ Invalid choice! Please enter a number between 1 and 5.")

if __name__ == "__main__":
    app = Checkers360()
    app.run()
