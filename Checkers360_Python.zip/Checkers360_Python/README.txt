# Checkers360 Shopping Cart Application

**Author:** Thato Mofokeng  
**Student Number:** 601447  
**Language:** Python

## About the Project

Checkers360 is a command-line shopping cart application developed in Python. It simulates a simple shopping experience where users can browse available products, add items to a cart, remove items, and calculate the total cost of their purchases.

The application uses a predefined product inventory and updates stock quantities as items are added to or removed from the cart.

## Features

- **View available products:** Displays product names, prices, and available stock.
- **Add items to the cart:** Lets users select a product and specify a quantity.
- **View the cart:** Displays items, quantities, and subtotals.
- **Remove items:** Removes a specified quantity from the cart and returns it to available stock.
- **Calculate the total:** Calculates the cost of all items currently in the cart.
- **Input validation:** Handles invalid product choices, quantities, and non-numeric quantity input.
- **Interactive menu:** Provides a menu for navigating the application's functions.

## Products Included

| Product | Price | Initial Stock |
|---|---:|---:|
| Laptop | R12,000.00 | 6 |
| Headphones | R600.00 | 2 |

These sample products and quantities are defined in the source code.

## Technologies Used

- Python 3
- Object-oriented programming
- Dictionaries and tuples
- Loops and conditional statements
- Exception handling
- Command-line input and output

## Getting Started

### Requirements

- Python 3 installed on your computer
- A terminal or command prompt

No third-party Python packages are required by the current implementation.

### Installation and Execution

1. Clone the repository:

   git clone <YOUR-GITHUB-REPOSITORY-URL>
  
2. Navigate to the project folder:

   cd <YOUR-REPOSITORY-FOLDER>
   
3. Run the application:

   python Checkers360App.py
   
   On some Windows installations, use:

   py Checkers360App.py
  

Replace the placeholders with your actual GitHub repository URL and folder name.

## How to Use

When the application starts, select an option from the menu:

1. **Add to Cart** — select a product and enter the quantity.
2. **View Cart** — display the current cart and item subtotals.
3. **Remove from Cart** — select an item and specify how many units to remove.
4. **Calculate Total** — display the total cost of the current cart.
5. **Exit** — close the application.

The program validates quantities to ensure they are positive and do not exceed available stock or the quantity in the cart, as applicable.

## Project Structure

```text
Checkers360/
└── Checkers360App.py
```

`Checkers360App.py` contains the main application, inventory management, cart operations, and menu logic.

## Learning Outcomes

This project demonstrates practical application of:

- Object-oriented programming using classes and methods
- Data management with dictionaries and tuples
- Menu-driven command-line application development
- Inventory updates when cart contents change
- User input validation and exception handling
- Subtotal and total cost calculations

## Current Scope and Limitations

- The inventory is predefined in the source code.
- Product and cart data are stored in memory and reset when the program restarts.
- The application does not currently include a graphical interface, database, payment processing, or user accounts.

## Future Improvements

Potential enhancements include:

- Integrating a database to persist products and orders
- Adding functionality to manage products dynamically
- Implementing checkout and order summaries
- Adding automated unit tests
- Developing a graphical or web-based interface

## License

This project is shared for educational and portfolio purposes. Add an open-source license to the repository if you intend to permit reuse under specific terms.
